#include <iostream>
#include <mutex>
#include <atomic>

// Types and data needed
std::string data;// Shared data between master and worker
std::mutex m; // Ensures no race condition

// Synchronization between master and worker
std::condition_variable cv;

// Initial state of worker and master
//std::atomic<bool> workerReady = false;
//std::atomic<bool> masterReady = false;

std::atomic_flag lock = ATOMIC_FLAG_INIT;

void WorkerThread() {
    std::cout << "Worker is called...\n";
    // False state: wait until master sends data
    //std::unique_lock<std::mutex> myLock(m);

    if (lock.test_and_set(std::memory_order_acquire)) {
        std::cout << "Lock acquired." << std::endl;
    }// acquire lock
        

    if (lock.test(std::memory_order_relaxed)) {
        std::cout << "Worker lock still in effect." << std::endl;
    }// test lock
    
    lock.clear(std::memory_order_release); // release lock

    //cv.wait(myLock, []() {
    //    return lock.test();
    //    });

    // Now in True state
    std::cout << "Worker is processing data\n";
    data += " addition from worker";
    // Notify master // Postprocess
    //myLock.unlock(); 
    cv.notify_one();

    std::cout << "data is now: " << data << std::endl;
    std::cout << "Worker has exited..." << std::endl;
}

void MasterThread() {
    std::cout << "Master is called...\n"; std::thread worker(WorkerThread);
    data = "Master data";
    // Transition into True state

    std::lock_guard<std::mutex> myLock(m);

    if (lock.test_and_set(std::memory_order_acquire)) {
        std::cout << "Master lock acquired." << std::endl;
    }  // acquire lock

    if (lock.test(std::memory_order_relaxed)) {
        std::cout << "Still have a lock in master thread." << std::endl;
    }      // test lock

    std::cout << "Master has notified worker, wait for response...\n";
    lock.clear(std::memory_order_release); //release lock
    
    cv.notify_one();

    
        //std::unique_lock<std::mutex> myLock(m);
        //cv.wait(myLock, [] {
            //return lock.test();// masterReady.load();
            //});

    std::cout << "Master back again...\n";
    worker.join();
}

int main() {

    //Calling the master to get working
    MasterThread();
   

	return 0;
}