#include <iostream>
#include <ratio>


int main() {
	std::ratio<1, 3> third;	
	std::ratio<1, 100> percent;

	std::cout << "Numerator of third is: " << third.num << " and denominator of third is: " << third.den << std::endl;
	std::cout << "Numerator of percent is: " << percent.num << " and denominator of percent is: " << percent.den << std::endl;

	//+, -, *, and / example
	using three_fourths = std::ratio<3, 4>;
	using one_eighth = std::ratio<1, 8>;
	using sum = std::ratio_add<three_fourths, one_eighth>;
	using sub = std::ratio_subtract<three_fourths, one_eighth>;
	using mult = std::ratio_multiply<three_fourths, one_eighth>;
	using divide = std::ratio_divide<three_fourths, one_eighth>;

	std::cout << "3/4 + 1/8 = " << sum::num << '/' << sum::den << '\n';
	std::cout << "3/4 - 1/8 = " << sub::num << '/' << sub::den << '\n';
	std::cout << "3/4 x 1/8 = " << mult::num << '/' << mult::den << '\n';
	std::cout << "3/4 % 1/8 = " << divide::num << '/' << divide::den << '\n';


	return 0;
}