#include <thread>
#include <iostream>
#include <functional>
void Iprint(const std::string& s, int count) {

    for (int i = 0; i < count; i++) {
        std::cout << s << " ID: " << std::this_thread::get_id() << std::endl;
    }
}

class CallableTestThread {
public:
    int m_iterations;
    CallableTestThread(int iter) : m_iterations(iter) {}

    void operator() () {
        Iprint("Callable function Object", 5);
    }

};
class ThreadClassTest {
public:
    int a;
    ThreadClassTest(int n) : a(n) {}

    static void StaticThreadFunc(int a) {
        Iprint("Static Member Function", a);
    }

    void MemberFunc(int a) {
        Iprint("Bound Member Function", a);
    }
};

void ThreadTestFunc() {
    Iprint("Free function", 5);
}


class ActiveObject{
public:
    std::thread m_thread;
   
    

    ActiveObject(std::thread&& t) : m_thread(std::move(t)) {
        std::cout << "AO Ctor with thread param." << std::endl;
    }

    void operator () () {      
        std::cout << "We are in operator of ActiveObject class" << std::endl;
    }


    ~ActiveObject() {
        if (m_thread.joinable()) {
            m_thread.join();
            std::cout << "We are in the destructor and just joined the thread yay." << std::endl;
        }
        else {
            std::cout << "We weren't able to join the thread uh-oh." << std::endl;
        }
    }
    
};
void WorkerThread(std::exception_ptr& error) {
    try {
        throw -1; //just throw error right away BOOM
        error = std::exception_ptr();
    }
    catch (...) {
        error = std::current_exception();
        std::cout << "Error caught!" << std::endl;
        
    }
}


void Worker1() {
    auto func = [] (int a) {
    std::cout << "We are in the lambda and just output: " << a * a << std::endl;
    return a * a;
};
    std::thread t1(func, 5); //Thread with lambda function
    ActiveObject ao0(std::move(t1));
    
}



int main() {
    using namespace std::placeholders;
    try {
    
    /*code to show exception handling is working*/
    //std::exception_ptr error;
    //std::thread tError(std::bind(WorkerThread, std::ref(error)));
    //tError.join();
    //---------------------
    
    Worker1(); //active object with lambda function in this function call
    
    auto storedLambda = [](int a) {
        Iprint("Stored lambda ID: ", 5); 
    };


    //creating thread - free function 
    std::thread tFreeFunc(&ThreadTestFunc);
    ActiveObject ao1(std::move(tFreeFunc));

    //creating thread - static member function 
    std::thread tStaticMemberFunc(&ThreadClassTest::StaticThreadFunc, 5);
    ActiveObject ao2(std::move(tStaticMemberFunc));

    //creating thread - binding a member function 
    ThreadClassTest cTest(5);
    auto boundFunc = std::bind(&ThreadClassTest::MemberFunc, &cTest, _1);
    std::thread tBindFunc(boundFunc, 5);
    std::thread::id ID = tBindFunc.get_id();
    ActiveObject ao3(std::move(tBindFunc));

    //creating thread - callable function object
    CallableTestThread callObj(5);
    std::thread tCallObj(callObj);
    ActiveObject ao4(std::move(tCallObj));

    //creating thread - stored lambda 
    std::thread tStoredLambda(storedLambda, 5);
    ActiveObject ao5(std::move(tStoredLambda));

    //creating thread - lambda
    std::thread tLambda([]() { Iprint("Free Lambda", 10); std::cout << std::endl; });
    ActiveObject ao6(std::move(tLambda));

    }

    catch (std::exception& e) {
        std::cout << "Exception caught: " << e.what() << std::endl;
    }
    catch (...) {
        std::cout << "Another error was caught." << std::endl;
    }
    
    
    
    return 0;
}
