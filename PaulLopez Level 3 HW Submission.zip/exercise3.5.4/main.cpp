#include <iostream>
#include "SyncedQueue.hpp"
#include <mutex>
#include <queue>
#include <atomic>

//updated code to use std::priority_queue instead of simple std::queue.

int main() {

	int nrProducers = 10; // 3; // 5; // 100;
	int nrConsumers = 10; // 3; // 5; // 100;

	SyncedQueue<std::string> queue;

	//create producers and consumers
	for (int i = 0; i < nrProducers; i++) {
		Producer p(i, &queue);
		Consumer c(i, &queue);
		std::thread producer(p);
		std::thread consumer(c);

		std::this_thread::sleep_for(std::chrono::milliseconds(100));

		producer.join();
		consumer.join();
	}

	std::cout << "Press enter to exit." << std::endl;
	getchar(); //stops at the end and need to hit enter for code to exit.


}