#include <iostream>
#include <chrono>
#include <random>
#include <thread>
#include <future>
#include <queue>

double compute(double x, double y) {
    std::default_random_engine dre(42);  // Wait a while
    std::uniform_int_distribution<int> delay(0, 1000);
    std::this_thread::sleep_for (std::chrono::milliseconds(delay(dre)));

    return std::cos(x) * std::exp(y);
}

void Dequeue(std::packaged_task<double(double, double)>& pt, double a, double b) {
    std::shared_future<double> result = pt.get_future();
    std::thread t1(std::move(pt), a, b);
    std::cout << "Result: " << result.get() << std::endl;
    t1.join();
    //return result.get();
} 

int main() {

    double x = 0.0;
    double y = 2.71;
    // A. 'Direct' tasks
    std::future<double> fut = std::async(compute, x, y);
    std::queue<double> queue;

    // Get the shared data
    double result1 = fut.get();
    std::cout << "Result: " << result1 << '\n';

    //using package task
    std::packaged_task<double(double, double)> task(compute);
    std::future<double> result2 = task.get_future();

    std::thread task_th(std::move(task), 0.0, 2.71);
    std::cout << "Result: " << result2.get() << std::endl;
    task_th.join();
    //Create a queue of packaged tasks, dequeue each task and execute it.

    const int N = 25;
    std::queue<std::packaged_task<double(double, double)>> queue_task;

    //std::packaged_task<double(double, double)> newTask(compute);

    for (int i = 0; i < N; i++) {
        std::packaged_task<double(double, double)> newTask(compute);
        queue_task.push(std::move(newTask));
        x += i/10.0;
        y += i/10.0;
        Dequeue(queue_task.front(), x, y);
        queue_task.pop();
    }

	return 0;
}