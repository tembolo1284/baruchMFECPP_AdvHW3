#include <memory>
#include <iostream>
#include <random>
#include <cmath>
#include<thread>
#include<chrono>
#include <array>
#include <functional>
struct X {
    double val;

    X() : val(0.0) {}
    void operator ()() {
        std::cout << "An X " << val << std::endl;
    }
};

template <typename T>
using GenericPointerType = std::shared_ptr<T>;
using PointerType = GenericPointerType<X>;

std::random_device rd;  //Will be used to obtain a seed for the random number engine
std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
std::uniform_int_distribution<> distrib(1, 5);

void Modify(PointerType& p, double newVal) {
    // Wait a while, long enough to trigger the race
    auto randNum = distrib(gen); //1, 2, 3, 4, 5.
    std::cout << "We are sleeping for: " << randNum * 1000 << "milliseconds seconds." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(randNum*1000));
    p->val = newVal; 
    
    std::cout << "Value of ptr: " << p->val << std::endl;
}


int main() {
   
    std::array < std::thread, 100> threadArr;

    for (int i = 0; i < threadArr.size() ; i++) {
        PointerType ptr(new X); //create a new instance of PointerType in each loop iteration
        threadArr[i] = std::thread(std::bind(&Modify, ptr, i));
    }
    
    for (int i = 0; i < threadArr.size(); i++) {
        threadArr[i].join();
    }

    //like in previous exercises, the output prints out all wildly out of order (if it doesn't crash first).
    //Truly ugly output haha.

}