#include <iostream>
#include <queue>

int main() {
	std::priority_queue<long long> q1;
	q1.push(66);
	q1.push(22);
	q1.push(44);
	std::cout <<"q1 top element is: " << q1.top() << std::endl;
	q1.pop();
	q1.push(11);
	q1.push(22);
	q1.push(33);
	q1.pop();

	while (q1.size() != 0) {
		std::cout<< "top element is: " << q1.top() << std::endl;
		q1.pop();
	}

	std::priority_queue<long long, std::deque<long long>, std::greater<long long>> q2;

	q2.push(66);
	q2.push(22);
	q2.push(44);
	std::cout << "\nq2 top element is : " << q2.top() << std::endl;
	q2.pop();
	q2.push(11);
	q2.push(22);
	q2.push(33);
	q2.pop();

	while (q2.size() != 0) {
		std::cout << "top element is: " << q2.top() << std::endl;
		q2.pop();
	}

	auto lambdaCompare = [](long long left, long long right) {  //stole this lambda pretty much from cppreference. I just flipped the sign
		return (left ^ 1) > (right ^ 1); 
	};
	std::priority_queue<long long, std::deque<long long>, decltype(lambdaCompare)> q3(lambdaCompare);

	q3.push(66);
	q3.push(22);
	q3.push(44);
	std::cout << "\nq3 top element is : " << q3.top() << std::endl;
	q3.pop();
	q3.push(11);
	q3.push(22);
	q3.push(33);
	q3.pop();

	while (q3.size() != 0) {
		std::cout << "top element is: " << q3.top() << std::endl;
		q3.pop();
	}
	return 0;
}