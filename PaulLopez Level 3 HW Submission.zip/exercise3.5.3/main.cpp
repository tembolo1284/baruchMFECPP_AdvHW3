#include <forward_list>
#include <iostream>
#include <iterator>
#include <list>
#include <iterator>

template <typename T>
T GetSize(std::forward_list<T> fl) {
	T result = std::distance(fl.begin(), fl.end());
	return result;
}


template <typename T>
void InsertAfter(std::forward_list<T>& fl, size_t val, size_t count) {
	int tempCounter{};
	auto iter = fl.begin();
	while (tempCounter < count-1) {
		++iter;
		tempCounter++;
	}

	iter = fl.insert_after(iter, val);
}

//Create functions to erase values after a given position as well as in a range of iterators.
template <typename T>
void EraseAfter(std::forward_list<T>& fl, int eraseVal, int count) {
	int tempCounter{};
	auto iterBegin = fl.begin();
	while (tempCounter < count) {
		++iterBegin;
		tempCounter++;
	}

	while (iterBegin != fl.end()) {
		auto removeVal = std::remove(iterBegin, fl.end(), eraseVal);
		++iterBegin;
	}
}

template <typename T>
void EraseAfter(std::forward_list<T>& fl, int beginPos, int endPos, int eraseVal) {
	auto iter_begin = fl.begin();
	auto iter_end = fl.begin();
	int size = GetSize(fl);


	if (beginPos >= size || endPos >= size || beginPos > endPos) {
		std::cout << "Sorry, your inputs aren't correct." << std::endl;
		return;
	}
	
	for (int i = 0; i < beginPos; i++) {
		iter_begin++;
	}
	for (int i = 0; i < endPos; i++) {
		iter_end++;
	}

	while (iter_begin != iter_end) {
		auto removeVal = std::remove(iter_begin, iter_end, eraseVal);
		++iter_begin;
	}
}

int main() {
	std::forward_list<int> l1 = { 7, 8, 5, 16, 8, 11};

	std::cout << "l1 size = " << GetSize(l1) << std::endl;

	InsertAfter(l1, 1000, 2);

	std::cout << "\nl1 after InsertAfter function: ";
	for (auto elem : l1) {
		std::cout << elem << ", ";
	}

	std::cout << "\n";
	EraseAfter(l1, 16, 3);
	std::cout << "\nl1 after EraseAfter function: ";
	for (auto elem : l1) {
		std::cout << elem << ", ";
	}

	std::forward_list<int> lIter = { 7, 8, 5, 16, 8, 11, 9, 12, 8 };

	std::cout << "\nlIter before EraseAfter function: ";
	for (auto elem : lIter) {
		std::cout << elem << ", ";
	}

	EraseAfter(lIter, 3, 7, 8); //start in 4th element, up to 8th element, and remove the value 8
	std::cout << "\nlIter after EraseAfter function: ";
	for (auto elem : lIter) {
		std::cout << elem << ", ";
	}

	
	//splice example
	std::forward_list<int> l2 = { 8, 88, 888, 8888, 88888, 888888, 8888888 };
	std::forward_list<int> l3 = { 11, 22, 33, 44, 55, 66, 77, 88 };

	auto it = l2.begin();
	std::advance(it, 4);

	l2.splice_after(it, l3); //will grab l3 and place it starting in 5th slot of l2
	std::cout << "\nSplice example:" << std::endl;
	std::cout << "l2: ";
	for (auto elem : l2) {
		std::cout << elem << ", ";
	}
	std::cout << "\nl3: ";
	for (auto elem : l3) {
		std::cout << elem << ", ";
	}

	//merge example
	std::cout << "\nMerge Example: " << std::endl;
	std::forward_list<int> l4 = {1, 1, 1, 1, 1,};
	l2.sort(); //need to sort both lists before I can merge.
	l4.sort();
	l4.merge(l2);  //grab l2 and pop it on the end of l4
	std::cout << "l2: ";
	for (auto elem : l2) {
		std::cout << elem << ", ";
	}
	std::cout << "\nl4: ";
	for (auto elem : l4) {
		std::cout << elem << ", ";
	}

	return 0;
}