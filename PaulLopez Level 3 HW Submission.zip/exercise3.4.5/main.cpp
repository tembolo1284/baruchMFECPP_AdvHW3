#include <iostream>
#include <numeric>
#include <chrono>
#include <vector>
#include <cmath>
#include <future>
#include <functional>
#include <execution>
#include <algorithm>
#include <omp.h>
#include <ppl.h>
#include <random>

using namespace concurrency;

struct same : std::binary_function<long long, long long, bool>{
    long long operator()(long long a, long long b) const { 
        return a * b; }
};


template <typename T>
long SumPara(T start, T end){
    auto length = end - start;
    if (length < 1000)                
        return std::accumulate(start, end, 0); //use accumulate if size of vec < 1000
    else {
        T mid = start + length/2;    
        long sum = SumPara(start, mid);
        auto temp = std::async(std::launch::async, SumPara<T>, mid, end);
        return (sum + temp.get());
    }

}

long SumParaThreadAccumulator{};
template <typename T>
long SumParaThread(T start, T end) {
    auto length = end - start;
    if (length < 1000) {
        SumParaThreadAccumulator += std::accumulate(start, end, 0); //use accumulate if size of vec < 1000
    }
    else {
        T mid = start + length / 2;
        //long sum = SumPara(start, mid);
        std::thread t1(SumParaThread<T>, start, mid);
        std::thread t2(SumParaThread<T>, mid, end);
        t1.join();
        t2.join();
    }

    return SumParaThreadAccumulator;
}

int main() {

	//Create a huge numeric array and sum its elements using std::accumulate(). 
	//Measure processing time.
	std::vector<long> vec;
    const long N = 1'000'000;

	for (int i = 1; i < N+1; i++) {
		vec.push_back(i);
	}

    // sum first method
    std::chrono::time_point<std::chrono::system_clock> start1, end1;
    start1 = std::chrono::system_clock::now();
	int sum1 = std::accumulate(vec.begin(), vec.end(), 0);
    end1 = std::chrono::system_clock::now();
    std::cout << "vec Size = " << N << std::endl;
	std::cout << "First method (stl accumulate) sum = " << sum1 << std::endl;

    std::chrono::duration<double> elapsed_seconds1 = end1 - start1;
    std::time_t end_time1 = std::chrono::system_clock::to_time_t(end1);
    std::cout << "Finished computation at elapsed time: " << elapsed_seconds1.count() << "s\n";


    // sum second method
    std::chrono::time_point<std::chrono::system_clock> start2, end2;
    start2 = std::chrono::system_clock::now();

    std::cout << "Second method (split calc into 2) sum = " << SumPara(vec.begin(), vec.end()) << std::endl;
    
    end2 = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds2 = end2 - start2;
    std::time_t end_time2 = std::chrono::system_clock::to_time_t(end2);
    std::cout << "Finished computation at elapsed time: " << elapsed_seconds2.count() << "s\n";

    

    // sum third method
    std::chrono::time_point<std::chrono::system_clock> start3, end3;
    start3 = std::chrono::system_clock::now();
    
    int sumParallel{};
    omp_set_num_threads(2);
    #pragma omp parallel for reduction (+:sumParallel) //had to enable in properties to get it working.
    for (long i = 0; i < vec.size(); ++i) {
        sumParallel += vec[i];
    }
    end3 = std::chrono::system_clock::now();
    std::cout << "Third method (omp parallel) sum = " << sumParallel << std::endl;
    std::chrono::duration<double> elapsed_seconds3 = end3 - start3;
    std::time_t end_time3 = std::chrono::system_clock::to_time_t(end3);
    std::cout << "Finished computation at elapsed time: " << elapsed_seconds3.count() << "s\n";

    // sum fourh method
    std::chrono::time_point<std::chrono::system_clock> start4, end4;
    start4 = std::chrono::system_clock::now();

    std::cout << "Fourth method (thread) sum = " << SumParaThread(vec.begin(), vec.end()) << std::endl;

    end4 = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds4 = end4 - start4;
    std::time_t end_time4= std::chrono::system_clock::to_time_t(end4);
    std::cout << "Finished computation at elapsed time: " << elapsed_seconds4.count() << "s\n";

    std::vector<long long> vec1;
    const int M = 12;// 1'000'000;

    for (int i = 1; i < M + 1; i++) {
        vec1.push_back(i);
    }

    long long product = std::accumulate(vec1.begin(), vec1.end(), 1, same());
    std::cout << "accumulator product of vec elements: " << product << std::endl;


    // std::transform, std::sort, std::for_each

    std::vector<int> vec2;
    
    const int MAX = 1'000'000;
    const int halfMax = MAX / 2;
    for (int i = 0; i < MAX; i++) {
        vec2.push_back(i);
    }
    std::vector<int> vecNeg(vec2.size());
    std::vector<int> vecNeg2(vec2.size());
    // transform 1st method
    std::chrono::time_point<std::chrono::system_clock> startTransform1, endTransform1;
    startTransform1 = std::chrono::system_clock::now();
    
    std::transform(vec2.begin(), vec2.end(), vecNeg.begin(), [&](int a) {
        return -a;
        });

    endTransform1 = std::chrono::system_clock::now();
    std::cout << "\nTransform first method: ";

    std::chrono::duration<double> elapsed_secondsTransform1 = endTransform1 - startTransform1;
    std::time_t end_timeTransform1 = std::chrono::system_clock::to_time_t(endTransform1);
    std::cout << "Finished computation at elapsed time: " << elapsed_secondsTransform1.count() << "s\n";
    
    for (int i = 0; i < 10; i++) {
        std::cout << vecNeg[i] << ", ";
    }

    // transform 2nd method
    std::chrono::time_point<std::chrono::system_clock> startTransform2, endTransform2;
    startTransform2 = std::chrono::system_clock::now();
    
    parallel_transform(vec2.begin(), vec2.end(), vecNeg2.begin(), [&](int a) {
       return -a;
       });  

    endTransform2 = std::chrono::system_clock::now();
    std::cout << "\nTransform second method: ";

    std::chrono::duration<double> elapsed_secondsTransform2 = endTransform2 - startTransform2;
    std::time_t end_timeTransform2 = std::chrono::system_clock::to_time_t(endTransform2);
    std::cout << "Finished computation at elapsed time: " << elapsed_secondsTransform2.count() << "s\n";

    for (int i = 0; i < 10; i++) {
        std::cout << vecNeg2[i] << ", ";
    }

    // Sort 1st method
    std::chrono::time_point<std::chrono::system_clock> startSort1, endSort1;
    startSort1 = std::chrono::system_clock::now();

    std::sort(vec2.begin(), vec2.end(), std::greater<int>());

    endSort1 = std::chrono::system_clock::now();
    std::cout << "\n\nSort first method: ";
    std::chrono::duration<double> elapsed_secondsSort1 = endSort1 - startSort1;
    std::time_t end_timeSort1 = std::chrono::system_clock::to_time_t(endSort1);
    std::cout << "Finished computation at elapsed time: " << elapsed_secondsSort1.count() << "s\n";
    
    for (int i = 0; i < 10; i++) {
        std::cout << vec2[i] << ", "; //should be reversed from 9...0
    }

    // Sort 2nd method optimized
    std::chrono::time_point<std::chrono::system_clock> startSort2, endSort2;
    startSort2 = std::chrono::system_clock::now();
    
    parallel_sort(vec2.begin(), vec2.end());
    
    endSort2 = std::chrono::system_clock::now();
    std::cout << "\n\nSort second method: ";    
    std::chrono::duration<double> elapsed_secondsSort2 = endSort2 - startSort2;
    std::time_t end_timeSort2 = std::chrono::system_clock::to_time_t(endSort2);
    std::cout << "Finished computation at elapsed time: " << elapsed_secondsSort2.count() << "s\n";

    for (int i = 0; i < 10; i++) {
        std::cout << vec2[i] << ", "; //should be back to 0....9
    }

    // for each 1st method
    std::chrono::time_point<std::chrono::system_clock> startFind1, endFind1;
    startFind1 = std::chrono::system_clock::now();
    
    std::for_each(vec2.begin(), vec2.end(), [&](int a) {a++; });

    endFind1 = std::chrono::system_clock::now();
    std::cout << "\n\nFor Each first method: ";    
    std::chrono::duration<double> elapsed_secondsFind1 = endFind1 - startFind1;
    std::time_t end_timeFind1 = std::chrono::system_clock::to_time_t(endFind1);
    std::cout << "Finished computation at elapsed time: " << elapsed_secondsFind1.count() << "s\n";

    for (int i = 0; i < 10; i++) {
        std::cout << vec2[i] << ", "; 
    }

    // for each second method
    std::chrono::time_point<std::chrono::system_clock> startFind2, endFind2;
    startFind2 = std::chrono::system_clock::now();

    parallel_for_each(vec2.begin(), vec2.end(), [&](int a) {a++; });

    endFind2 = std::chrono::system_clock::now();
    std::cout << "\n\nFor Each second method: ";
    std::chrono::duration<double> elapsed_secondsFind2 = endFind2 - startFind2;
    std::time_t end_timeFind2 = std::chrono::system_clock::to_time_t(endFind2);
    std::cout << "Finished computation at elapsed time: " << elapsed_secondsFind2.count() << "s\n";

    for (int i = 0; i < 10; i++) {
        std::cout << vec2[i] << ", "; 
    }


	return 0;
}