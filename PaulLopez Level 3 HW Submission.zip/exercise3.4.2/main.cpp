#include <iostream>
#include <future>
#include <chrono>

bool infiniteSwitch = true;

int func1() {
	std::cout << "We are in func1." << std::endl;
	return 88;
}

int func2() {
	std::cout << "We are in func1." << std::endl;
	while (infiniteSwitch) {
		if (!infiniteSwitch) {
			break;
		}
	}
	return 5;
}

double sum2(double a, double b) {
	return a + b;
}

int main() {
	std::future<int> fut1 = std::async(func1);
	std::shared_future<int> ready_future1 = fut1.share();
	std::shared_future<int> ready_future2 = fut1.share();

	std::cout << "ready_future1 " << ready_future1.get() << std::endl;
	std::cout << "ready_future1 second time " << ready_future1.get() << std::endl;
	//I'm able to call shared_future twice without any issues
	
	//std::cout << "ready_future2 " << ready_future2.get() << std::endl;
	//ready_future2 gives me an exception

	//all built in functions for future seem to be available for shared_future as well

	std::future<int> fut2 = std::async(func2);
	std::shared_future<int> sfut_timeout = fut2.share();
	
	std::chrono::system_clock::time_point five_seconds_passed = std::chrono::system_clock::now() + std::chrono::seconds(5);

	try {
		if (std::future_status::ready == sfut_timeout.wait_until(five_seconds_passed)) {
			std::cout << "sfut_timeout: " << sfut_timeout.get() << "\n";
		}
		else {
			std::cout << "sfut_timeout has timed out!\n";
			infiniteSwitch = false; //hack to get out of infinite loop.
			throw std::exception();
			//you'll need to ctrl + c to break out of the infinite loop worst case scenario.
		}
	}
	catch (std::exception e) {
		std::cout << "Exception from timeout caught: " << e.what() << std::endl;
	}
	return 0;
}