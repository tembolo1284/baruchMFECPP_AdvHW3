#include <functional>
#include <iostream>
#include <thread>
#include <queue>
#include "Command.hpp"

using FunctionType = std::function<double(double)>;

double func(double a) {
    return a * 2;
}

int main() {
    FunctionType f_times2 = [](double a) { 
        return a * 2; 
    };
    
    Command c1(f_times2, 11);
    Command c2(f_times2, 22);
    Command c3(f_times2, 33);
    Command c4(f_times2, 44);
    Command c5(f_times2, 55);
    
    std::priority_queue<Command, std::vector<Command>, std::less<Command>> p1;
    p1.push(std::move(c1));
    p1.push(std::move(c3));
    p1.push(std::move(c5));
    p1.push(std::move(c2));
    p1.push(std::move(c4));

    while (p1.size() != 0) {
        std::cout << "Top element is: " << p1.top() << std::endl;
        std::cout << "Execute value is: ";
        p1.top().Execute(5.0); //should spit out 5 * 2 = 10 for each iteration.
        p1.pop();
        std::cout << std::endl;
    }

    std::cout << "Queue is now empty thanks for playing." << std::endl;

	return 0;
}