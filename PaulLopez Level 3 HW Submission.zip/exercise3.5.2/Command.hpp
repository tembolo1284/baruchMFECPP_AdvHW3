#ifndef Command_HPP
#define Command_HPP

#include <functional>
#include <chrono>
#include <thread>
#include <iostream>

class Command {
    using FunctionType = std::function<double(double)>;

private:
    long ID; // priority of command
    FunctionType algo;
public:
    Command(const FunctionType& algorithm, const long priority); //: algo(algorithm), ID(priority) {}

    void Execute(const double x) const; 

    int priority() const;

    bool operator < (const Command& c) const; 
    bool operator > (const Command& c) const; 

    friend std::ostream& operator << (std::ostream& os, const Command& c);
    
};

//#ifndef Command_cpp 
//#include "Command.cpp"
//#endif

#endif
