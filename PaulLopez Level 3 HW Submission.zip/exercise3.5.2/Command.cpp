#ifndef Command_CPP
#define Command_CPP
#include "Command.hpp"

Command::Command(const FunctionType& algorithm, const long priority) : algo(algorithm), ID(priority) {}

void Command::Execute(const double x) const {
    // Introduce delay to simulate a heavy algorithm
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    std::cout << algo(x) << '\n';
}

int Command::priority() const {
    return ID;
}

bool Command::operator < (const Command& c) const {
    return (ID < c.ID);
}

bool Command::operator > (const Command& c) const {
    return (ID > c.ID);
}

std::ostream& operator << (std::ostream& os, const Command& c) {
    os << c.priority();
    return os;
}

#endif
