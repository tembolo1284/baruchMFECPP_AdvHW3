#include <iostream>
#include "SyncedQueue.hpp"
#include <mutex>
#include <queue>
#include <atomic>
//took the SyncedQueue.hpp code from prof Duffy's lecture. Only difference is it was translated as much as possible 
//into std instead of boost.

int main() {

	int nrProducers = 10; // 3; // 5; // 100;
	int nrConsumers = 1; // 3; // 5; // 100;

	SyncedQueue<std::string> queue;

	//create producers and consumers
	for (int i = 0; i < nrProducers; i++) {
		Producer p(i, &queue);
		Consumer c(0, &queue);
		std::thread consumer(c);
		std::thread producer(p);
		producer.join();
		consumer.join();
	}
	

	std::cout << "Press enter to exit." << std::endl;
	getchar(); //stops at the end and need to hit enter for code to exit.


}