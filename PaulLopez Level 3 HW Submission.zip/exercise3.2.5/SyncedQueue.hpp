#ifndef SyncedQueue_HPP
#define SyncedQueue_HPP
#include <queue>
#include <mutex>
#include <chrono>
#include <string>
#include <atomic>

std::atomic<bool> breakFlag = true;
std::atomic<int> ctr{};

template <typename T>
class SyncedQueue {
public:
	std::queue<T> m_queue;
	std::mutex m_mutex;
	std::condition_variable m_cond;

	void Enqueue(const T& input) {
		std::unique_lock<std::mutex> lock(m_mutex);
		m_queue.push(input);
		m_cond.notify_one(); // let everyone know data is ready
	}

	T Dequeue() {
		std::unique_lock<std::mutex> lock(m_mutex);
		while (m_queue.size() == 0) {
			//m_cond.wait(lock); //Must wait until something is in there.
			m_cond.wait_for(lock, std::chrono::seconds(2)); 
		}
		T result = m_queue.front();
		m_queue.pop();
		return result;
	}
};

class Producer {
public:
	int m_id;
	SyncedQueue<std::string>* m_queue;

	Producer(int id, SyncedQueue<std::string>* queue) {
		m_id = id;
		m_queue = queue;
	}
	void operator () () {
		int data = 0;
		std::mutex p_mutex;
		std::cout << "Customer " << m_id << " is waiting" << std::endl;
		std::this_thread::sleep_for(std::chrono::seconds(2));
		//if (ctr == 0) {
			breakFlag = true; //resets breakFlag to true also for the next instance so while loop will work
		//}
		while (breakFlag) {
			//produce data and store in the queue
			std::string str = "\nCustomer " + std::to_string(m_id) + " is getting haircut.";
			m_queue->Enqueue(str);
			std::cout << str << std::endl;
			
			std::this_thread::sleep_for(std::chrono::seconds(2)); //2 seconds here and above will make it 4 seconds a new customers shows up.
			//Can easily adjust to make it 10 seconds as per original requirement
			
				breakFlag = false; //interrupts and gets us out of here
			
		}
	}
};

	class Consumer {
	public:
		int m_id;
		SyncedQueue<std::string>* m_queue;

		Consumer(int id, SyncedQueue<std::string>* queue) {
			m_id = id;
			m_queue = queue;
		}
		void operator () () {
			std::mutex c_mutex;
			std::cout << "Barber is ready for action." << std::endl;
			
			//if (ctr == 0) {
				breakFlag = true; //resets breakFlag to true also for the next instance so while loop will work
			//}
			while (breakFlag) {
				
				//std::cout << std::to_string(m_id).c_str() << " ";
				m_queue->Dequeue();
				//std::cout << "\Haircut done for " << std::to_string(m_id) << std::endl;// << m_queue->Dequeue().c_str() << ")" << std::endl;

				std::this_thread::sleep_for(std::chrono::seconds(2));
				
				if (c_mutex.try_lock()) {
					std::cout << "Barber done with customer " << ctr << std::endl;
					ctr++;
					//if (ctr == 1) { //Haircut done and time for next dude. 
						breakFlag = false; //interrupts and gets us out of here
					//}
					c_mutex.unlock();
				}
			}
		}
	};


#endif