#include <iostream>
#include <chrono>
#include <thread>
#include "StopWatch.hpp"

int main() {
	StopWatch sw1;

	sw1.StartStopWatch();
	std::this_thread::sleep_for(std::chrono::milliseconds(1500));
	sw1.StopStopWatch();

	std::cout << "Finished computation at elapsed time: " << sw1.GetTime() << "s\n";//give or take 1.5 seconds

	sw1.Reset();

	std::cout << "Finished computation at elapsed time: " << sw1.GetTime() << "s\n";//give or take 0 seconds after reset

	sw1.StartStopWatch();
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	sw1.StopStopWatch();

	std::this_thread::sleep_for(std::chrono::milliseconds(2000));

	sw1.StartStopWatch();
	std::this_thread::sleep_for(std::chrono::milliseconds(3000));
	sw1.StopStopWatch();

	std::cout << "Finished computation at elapsed time: " << sw1.GetTime() << "s\n";//give or take 5 seconds

	sw1.StartStopWatch();
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	sw1.StopStopWatch();

	std::cout << "Finished computation at elapsed time: " << sw1.GetTime() << "s\n";//give or take 7 seconds

	StopWatch sw2=sw1;
	StopWatch sw3(sw2);

	std::cout << "Finished computation at elapsed time: " << sw2.GetTime() << "s\n";//also 7ish seconds


	sw3.StartStopWatch();
	std::this_thread::sleep_for(std::chrono::milliseconds(3000));
	sw3.StopStopWatch();
	std::cout << "Finished computation at elapsed time: " << sw3.GetTime() << "s\n";//10ish seconds
	sw1.Reset();
	std::cout << "Finished computation at elapsed time: " << sw1.GetTime() << "s\n";//give or take 0 seconds

	return 0;


}