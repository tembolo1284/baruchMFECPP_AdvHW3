#include <iostream>
#include <future>

void func1() {
    std::cout << "We are inside func1." << std::endl;
}

double func2(double a, double b) {
    std::cout << "We are in func2." << std::endl;
    return a + b;
}

int main() {

    auto x1 = std::async(&func1);
    auto x2 = std::async(&func2, 5, 10);

    std::cout << "Result of x2 = " << x2.get() << std::endl;
    //output is a mess! I didn't expect that. Example output to console below:
    //Result of x2 = We are in func2.We are inside func1.

    //    15

    //std::cout << "Second attempt to get result of x2 = " << x2.get() << std::endl;
    
    //Got the below exception running the above line of code
    //Unhandled exception at 0x00007FFFBB864FD9 in exercise3.4.1.exe: Microsoft C++ exception: 
    //std::future_error at memory location 0x0000009E2CB1F180.

    auto x3 = std::async(std::launch::async,&func1);
    auto x4 = std::async(std::launch::async,&func2, 10, 20);

    std::cout << "\nResult of x4 = " << x4.get() << std::endl;
    //Much better output. Example output is below:
    //We are inside func1.
    //We are in func2.
    //Result of x4 = 
    //30

    auto x5 = std::async(std::launch::async, &func1);
    auto x6 = std::async(std::launch::deferred, &func2, 30, 20);

    std::cout << "\nResult of x6 = " << x6.get() << std::endl;
    //Output is messy again. Example output below.
    //Result of x6 = We are in func2.
    //We are inside func1.
    //50


    
    return 0;
}