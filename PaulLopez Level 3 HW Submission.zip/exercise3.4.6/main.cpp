#include <iostream>
#include <chrono>
#include <functional>
#include <thread>
#include <future>

int FuncF1(int a) {
	std::cout << "Hello." << std::endl;
	for (int i = 0; i < 1'500'000'000; i++) {
		//visual basic style pause for fun
	}
	std::cout << "This is func F1" << std::endl;
	return a*2;
}

int FuncF2(int a) {
	std::this_thread::sleep_for(std::chrono::milliseconds(1500));
	std::cout << "This is func F2" << std::endl;
	return a * 3;
}

int FuncF3(int a) {
	std::this_thread::sleep_for(std::chrono::milliseconds(1500));

	std::cout << "This is func F3" << std::endl;
	return a * 4;
}
int FuncF4(int a) {
	std::this_thread::sleep_for(std::chrono::milliseconds(1500));
	std::cout << "This is func F4" << std::endl;
	return a * 5;
}

int result1Fut = 0;
int result2Fut = 0;
int result3Fut = 0;
int result4Fut = 0;

void FuncF1fut(std::future<int>& fut) {
	int result1Fut = fut.get() * 2;
	std::cout << "Hello." << std::endl;
	for (int i = 0; i < 1'500'000'000; i++) {
		//visual basic style pause for fun
	}
	std::cout << "This is func F1" << std::endl;
}

void FuncF2fut(std::future<int>& fut) {
	int result2Fut = fut.get() * 3;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	std::cout << "This is func F2" << std::endl;
}

void FuncF3fut(std::future<int>& fut) {
	int result3Fut =fut.get() * 4;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	std::cout << "This is func F3" << std::endl;
}
void FuncF4fut(std::future<int>& fut) {
	int result4Fut = fut.get() * 5;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	std::cout << "This is func F4" << std::endl;
}
int main() {
	const int a = 5;
	//single threaded method
	std::cout << "This is the single thread method." << std::endl;
	std::chrono::time_point<std::chrono::system_clock> start1, end1;
	start1 = std::chrono::system_clock::now();
	
	auto result1 = FuncF1(a);
	auto result2 = FuncF2(a);
	auto result3 = FuncF3(result2);
	auto result4 = result1 + result3;
	auto result5 = FuncF4(result4);
	

	end1 = std::chrono::system_clock::now();

	std::chrono::duration<double> elapsed_seconds1 = end1 - start1;
	std::time_t end_time1 = std::chrono::system_clock::to_time_t(end1);
	std::cout << "Finished computation at elapsed time: " << elapsed_seconds1.count() << "s\n";

	//using async
	std::cout << "\nThis is using async method." << std::endl;
	std::chrono::time_point<std::chrono::system_clock> start3, end3;
	start3 = std::chrono::system_clock::now();
	
	auto r1 = std::async(&FuncF1, a);
	auto r2 = std::async(&FuncF2, a);
	auto r3 = std::async(&FuncF3, r2.get());
	auto r4 = std::async(&FuncF4, r1.get() + r3.get());


	end3 = std::chrono::system_clock::now();

	std::chrono::duration<double> elapsed_seconds3 = end3 - start3;
	std::time_t end_time3 = std::chrono::system_clock::to_time_t(end3);
	std::cout << "Finished computation at elapsed time: " << elapsed_seconds3.count() << "s\n";

	

	//using promises and futs method
	std::cout << "\nThis is promises and futures method." << std::endl;
	std::chrono::time_point<std::chrono::system_clock> start2, end2;
	start2 = std::chrono::system_clock::now();

	std::promise<int> promise1;
	std::promise<int> promise2;
	std::promise<int> promise3;
	std::promise<int> promise4;
	std::future<int> fut1 = promise1.get_future();
	std::future<int> fut2 = promise2.get_future();
	std::future<int> fut3 = promise3.get_future();
	std::future<int> fut4 = promise4.get_future();

	std::thread t1(FuncF1fut, std::ref(fut1));
	promise1.set_value(a);
	std::thread t2(FuncF2fut, std::ref(fut2));
	promise2.set_value(a);
	std::thread t3(FuncF3fut, std::ref(fut3));
	promise3.set_value(result2Fut);
	
	std::thread t4(FuncF4fut, std::ref(fut4));
	promise4.set_value(result1Fut + result3Fut);
	
	t1.join();
	t2.join();
	t3.join();
	t4.join();

	end2 = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds2 = end2 - start2;
	std::time_t end_time2 = std::chrono::system_clock::to_time_t(end2);
	std::cout << "Finished computation at elapsed time: " << elapsed_seconds2.count() << "s\n";

	//using packaged tasks
	std::cout << "\nThis is using packaged tasks method." << std::endl;
	std::chrono::time_point<std::chrono::system_clock> start4, end4;
	start4 = std::chrono::system_clock::now();

	std::packaged_task<int(int)> task1(FuncF1);
	std::future<int> future1 = task1.get_future();
	
	std::packaged_task<int(int)> task2(FuncF2);
	std::future<int> future2 = task2.get_future();
	
	std::packaged_task<int(int)> task3(FuncF3);
	std::future<int> future3 = task3.get_future();
	
	std::packaged_task<int(int)> task4(FuncF4);
	std::future<int> future4 = task4.get_future();
	std::thread task1_th(std::move(task1), a);
	std::thread task2_th(std::move(task2), a);
	std::thread task3_th(std::move(task3), future2.get());
	std::thread task4_th(std::move(task4), future1.get() + future3.get());

	task1_th.join();
	task2_th.join();
	task3_th.join();
	task4_th.join();

	end4 = std::chrono::system_clock::now();

	std::chrono::duration<double> elapsed_seconds4 = end4 - start4;
	std::time_t end_time4 = std::chrono::system_clock::to_time_t(end4);
	std::cout << "Finished computation at elapsed time: " << elapsed_seconds4.count() << "s\n";
	

	

	return 0;
}