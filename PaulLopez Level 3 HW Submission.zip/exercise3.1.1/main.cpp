#include <iostream>
#include <thread>
#include <functional>

void Iprint(const std::string& s, int count) {
    
    for (int i = 0; i < count; i++) {
        std::cout << s << " ID: " << std::this_thread::get_id() << std::endl;
    }
}

class CallableTestThread {
public:
    int m_iterations;
    CallableTestThread(int iter) : m_iterations(iter) {}

    void operator() () {
        Iprint("Callable function Object", 50);
    }

};
class ThreadClassTest {
public:
    int a;
    ThreadClassTest(int n) : a(n) {}

    static void StaticThreadFunc(int a) {
        Iprint("Static Member Function", a);
    }

    void MemberFunc(int a) {
        Iprint("Bound Member Function", a);
    }
    

};

void ThreadTestFunc() {
    Iprint("Free function", 5);
}

int main() {
    //for keeping the time in part f) I could have timed each thread individually or 
    //keep time for the entire main.  I kept a separate piece to time the stored lambda function at the bottom.
    std::chrono::time_point
        <std::chrono::system_clock> startFull, endFull;
    startFull = std::chrono::system_clock::now();

    using namespace std::placeholders;
    auto storedLambda = [](int a) {
        Iprint("Stored lambda ID: ", 20);    };
    //creating thread - free function 
    std::thread tFreeFunc(&ThreadTestFunc);

    //creating thread - static member function 
    std::thread tStaticMemberFunc(&ThreadClassTest::StaticThreadFunc, 555);
    tStaticMemberFunc.detach(); //lucky staticThreadFunc detachment

    //creating thread - binding a member function 
    ThreadClassTest cTest(5);
    auto boundFunc = std::bind(&ThreadClassTest::MemberFunc,&cTest, _1);
    std::thread tBindFunc(boundFunc,300);
    std::thread::id ID = tBindFunc.get_id();

    //creating thread - callable function object
    CallableTestThread callObj(222);    
    std::thread tCallObj(callObj);


    //creating thread - stored lambda 
    std::thread tStoredLambda(storedLambda, 250);

    //creating thread - lambda
    std::thread tLambda([]() { Iprint("Free Lambda", 100); std::cout <<std::endl;}); // <-- ;}); that hurts to look at!

    //----------------------stored lambda function individual time test-------------------
    //Finished computation at elapsed time: 0.0092054s <---runs quite quickly
    /*  
    std::chrono::time_point
        <std::chrono::system_clock> startLambda, endLambda;
    startLambda = std::chrono::system_clock::now();


    //storedlambda thread creation part------------
    std::thread tStoredLambda2(storedLambda, 10);
    tStoredLambda2.join();
    //--------------------


    endLambda = std::chrono::system_clock::now();

    std::chrono::duration<double>
        elapsed_secondsLambda = endLambda - startLambda;
    std::time_t end_time =
        std::chrono::system_clock::to_time_t(endLambda);

    std::cout << "Finished computation at "
        << "elapsed time: "
        << elapsed_secondsLambda.count() << "s\n";
        */
    //----------------------------------------------------------



    //the output is a total car crash :). It all runs but hits the output screen at random times. It doesn't print nicely at all geez!
    //Finished computation at elapsed time: 0.0133462s  <---entire thing finishes very quickly!


    try {

        if (tFreeFunc.joinable()) {
            //throw 1;
            tFreeFunc.join();
        }
        else {
            throw 1;
        }
        if (tStaticMemberFunc.joinable()) {
            //throw 2; 
            tStaticMemberFunc.join();
        }
        else {
            //throw 2;
        }
        if (tBindFunc.joinable()) {
            //throw 3;
            tBindFunc.join();
        }
        else {
            throw 3;
        }
        if (tCallObj.joinable()) {
            //throw 4; 
            tCallObj.join();
        }
        else {
            throw 4;
        }
        if (tStoredLambda.joinable()) {
            //throw 5; 
            tStoredLambda.join();
        }
        else {
            throw 5;
        }
        if (tLambda.joinable()) {
            //throw 6; 
            tLambda.join();
        }
        else {
            throw 6;
        }
    }
    catch (int err) {
        switch (err) {
        case 1: {
            std::cout << "tFreeFunc join attempt" << std::endl;
            tFreeFunc.join();
            break; 
        }
        case 2: {
            std::cout << "tStaticMemberFunc join attempt" << std::endl;
            tStaticMemberFunc.join();
            break;
        }
        case 3: {
            std::cout << "tBindFunc join attempt" << std::endl;
            tBindFunc.join();
            break;
        }
        case 4: {
            std::cout << "tCallObj join attempt" << std::endl;
            tCallObj.join();
            break;
        }
        case 5: {
            std::cout << "tStoredLambda join attempt" << std::endl;
            tStoredLambda.join();
            break;
        }
        case 6: {
            std::cout << "tLambda join attempt" << std::endl;
            tLambda.join();
            break;
        }

        }
    
    }

    endFull = std::chrono::system_clock::now();

    std::chrono::duration<double>
        elapsed_secondsFull = endFull - startFull;
    std::time_t end_time =
        std::chrono::system_clock::to_time_t(endFull);

    std::cout << "Finished computation at "
        << "elapsed time: "
        << elapsed_secondsFull.count() << "s\n";
    return 0;
}