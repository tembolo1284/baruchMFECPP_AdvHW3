#include <atomic>
#include <iostream>


int main() {
	std::atomic_llong atomLlong (std::numeric_limits<long long>::min());
	std::atomic_bool atomBool(true);
	std::atomic_int atomInt(1000);
	std::atomic_llong atomLlong2;

	std::cout << "Is atomLlong lock free? " << std::boolalpha << atomLlong.is_lock_free() << std::endl;
	std::cout << "Is atomBool lock free? " << atomBool.is_lock_free() << std::endl;
	std::cout << "Is atomInt lock free? " << atomInt.is_lock_free() << std::endl;

	std::cout << "\nCurrent values of both llongs, bool, and int atomic objects are: " <<
		atomLlong.load() << ", " << atomLlong2.load() << ", " << atomBool.load() << ", " << atomInt.load() << std::endl;

	atomLlong2.store(atomLlong);

	std::cout << "Values of llongs, bool, and int atomic objects now are: " <<
		atomLlong.load() << ", " << atomLlong2.load() << ", " << atomBool.load() << ", " << atomInt.load() << std::endl;



	return 0;
}