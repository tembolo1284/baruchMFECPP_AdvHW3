#ifndef SyncedQueue_HPP
#define SyncedQueue_HPP
#include <queue>
#include <mutex>
#include <chrono>
#include <string>
#include <atomic>
#include "Command.hpp"

std::atomic<bool> breakFlag = true;
std::atomic<int> ctr{};
std::atomic<int> IDMaker{};
using FunctionType = std::function<double(double)>;


template <typename T>
class SyncedQueue {
public:
	std::priority_queue<T> m_queue;
	std::mutex m_mutex;
	std::condition_variable m_cond;

	
	void Enqueue(const T& input) {
		std::unique_lock<std::mutex> lock(m_mutex);
		m_queue.push(input);
		m_cond.notify_one(); // let everyone know data is ready
	}

	T Dequeue() {
		std::unique_lock<std::mutex> lock(m_mutex);
		while (m_queue.size() == 0) {
			//m_cond.wait(lock); //Must wait until something is in there.
			m_cond.wait_for(lock, std::chrono::seconds(2)); //changed to sleep for 2 secs and then wake up
			//wait_for is my main notificaiton mechanism. Admittedly arbitrary I found 2 secs is more than enough to not get stuck in this loop
			
		}
	
		T result = m_queue.top(); //Always pop the top priority. Little different that queueu previously
		m_queue.pop();
		return result;
	}
};


class Producer {
public:
	int p_id;
	SyncedQueue<Command>* p_queue;

	Producer(int id, SyncedQueue<Command>* queue) {
		p_id = id;
		p_queue = queue;
	}

	void operator () () {
		FunctionType f_times2 = [](double a) {
			return a * 2;
		};
		int data = 0;
		std::mutex p_mutex;
		std::cout << "Producer Operator with ID: " << p_id << std::endl;
		if (ctr == 0) {
			breakFlag = true; //resets breakFlag to true also for the next instance so while loop will work
		}

		while (breakFlag) {
			//produce data and store in the queue
			// command creation before Enqueing it
			Command c(f_times2, p_id+IDMaker); //producer always produces no matter what. Consumer decides what is "special" and when to stop.
			p_queue->Enqueue(c);
			std::cout << "Command ID: " << c.priority() << std::endl;
			IDMaker++;

			std::this_thread::sleep_for(std::chrono::milliseconds(50));
			if (ctr == 5) {
				breakFlag = false; //interrupts and gets us out of here
			}
		}
	}
};


	class Consumer {
	public:
		int c_id;
		SyncedQueue<Command>* c_queue;

		Consumer(int id, SyncedQueue<Command>* queue) {
			c_id = id;
			c_queue = queue;
		}
		void operator () () {

			if (c_id > 5) { //or whatever we want. We are done and no longer processing. This is the "special" command that tells us to stop.
				std::cout << "No processing when consumer ID > 5. Thanks for stopping by." << std::endl;
				return;
			}
			std::mutex c_mutex;

			std::cout << "Consumer Operator with ID: " << c_id << std::endl;
			ctr = 0; //reset counter for the next instance
			if (ctr == 0) {
				breakFlag = true; //resets breakFlag to true also for the next instance so while loop will work
			}
			while (breakFlag) {
				
				std::cout << "Consumer " << std::to_string(c_id).c_str() << " ";
				std::cout << "\nconsumed Command with priority ID: " << c_queue->Dequeue() << "" << std::endl;

				std::this_thread::sleep_for(std::chrono::milliseconds(200));
				
				ctr++;
				if (c_mutex.try_lock()) {
					std::cout << "Consumer Lock achieved!" << std::endl;
					if (ctr == 5) { //give it about 5 runs then stop. 
						breakFlag = false; //interrupts and gets us out of here
					}
					c_mutex.unlock();
				}
	
			}
		}
	};


#endif