#include <functional>
#include <iostream>
#include <thread>
#include <queue>
#include "Command.hpp"
#include "SyncedQueue.hpp"

using FunctionType = std::function<double(double)>;

double func(double a) {
    return a * 2;
}

int main() {
    
    FunctionType f_times2 = [](double a) { 
        return a * 2; 
    };

    int nrProducers = 10; // 3; // 5; // 100;
    int nrConsumers = 10; // 3; // 5; // 100;

    SyncedQueue<Command> queue;

    //create producers and consumers
    for (int i = 0; i < nrProducers; i++) {
        
        Producer p(i, &queue);
        Consumer c(i, &queue);
        std::thread producer(p);
        std::thread consumer(c);

        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        producer.join();
        consumer.join();
    }

	return 0;
}