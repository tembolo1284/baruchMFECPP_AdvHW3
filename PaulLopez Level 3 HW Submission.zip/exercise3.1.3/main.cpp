#include <iostream>
#include <thread>
#include <functional>
#include <chrono>
#include <mutex>
#include <shared_mutex>

std::mutex tFreeFunc_mutex;
std::mutex tStaticMemberFunc_mutex;
std::mutex tBindFunc_mutex;
std::mutex tCallObj_mutex;
std::timed_mutex tCallObj_timed_mutex;
std::mutex tStoredLambda_mutex;
std::mutex tLambda_mutex;


int tryLockCtr{};


void Iprint(const std::string& s, int count) {
    
    for (int i = 0; i < count; i++) {
        std::cout << s << " ID: " << std::this_thread::get_id() << std::endl;
    }
    tryLockCtr++; // <-- moved counter inside Iprint() function for part 3
}

class CallableTestThread {
public:
    int m_iterations;
    CallableTestThread(int iter) : m_iterations(iter) {}

    void operator() () {
        //tCallObj_mutex.lock();
        //bool locked = false;
        //while (!locked) {
            //if (tCallObj_mutex.try_lock()) {
                //const std::lock_guard<std::mutex> lock1(tCallObj_mutex); //commented out all the other code and just added this lock_guard
                // wait for a few seconds before lock attempts.
                std::this_thread::sleep_for(std::chrono::seconds(1));
               
                //std::unique_lock<std::mutex> lock1(tCallObj_mutex, std::defer_lock);
                std::unique_lock<std::timed_mutex> lock1(tCallObj_timed_mutex);
                lock1.unlock(); //if I uncomment this line I get an abort error since I never locked anything.
                //I need to unlock the thread using the above first if I am going to try the timed_mutex method of try_lock_until()
                //or try_lock_for() below
                
                //lock1.lock(); //if I only leave this line uncommented, I also get an abort error because I never unlock mutex
                auto now = std::chrono::system_clock::now();

                /*
                if (lock1.try_lock_until(now + std::chrono::milliseconds(30))) { //now plus 30 milliseconds
                    std::cout << "try_lock_until was successful!" << std::endl;
                } 
                else {
                    std::cout << "try_lock_until timed out." << std::endl;
                }
                */

                if (lock1.try_lock_for(std::chrono::milliseconds(50))) { //just tries for 50 milliseconds
                    std::cout << "try_lock_for was successful!" << std::endl;
                }
                else {
                    std::cout << "try_lock_until timed out." << std::endl;
                }
                //lock1.unlock();
               
                //if (lock1.try_lock()) { //doing the try_lock() call here
                //    std::cout << std::this_thread::get_id() << ", lock achieved!" << std::endl;
                //}
                //else {
                //    std::cout << std::this_thread::get_id() << ", failed getting lock." << std::endl;
               // }
               
                Iprint("Callable function Object", 100);
                
                //locked = true;
                //tCallObj_mutex.unlock();
                
                
                //lock1.release(); //<-- release frees up mutex and I didn't unlock it, but it also destroys the mutex and throws an abort error
                //if you aren't careful and put it in a place where the thread is still busy when you attempt to release it.
                
                
            //}
        //}
    }

};
class ThreadClassTest {
public:
    int a;
    ThreadClassTest(int n) : a(n) {}

    static void StaticThreadFunc(int a) {
        //tStaticMemberFunc_mutex.lock();
        //bool locked = false;
        //while (!locked) {
            //if (tStaticMemberFunc_mutex.try_lock()) {
                //const std::lock_guard<std::mutex> lock2(tStaticMemberFunc_mutex);
        std::unique_lock<std::mutex> lock2(tStaticMemberFunc_mutex, std::defer_lock);

        if (lock2.try_lock()) { //doing the try_lock() call here
            std::cout << std::this_thread::get_id() << ", lock achieved!" << std::endl;
        }
        else {
            std::cout << std::this_thread::get_id() << ", failed getting lock." << std::endl;
        }
                Iprint("Static Member Function", a);
                
                //locked = true;
                //tStaticMemberFunc_mutex.unlock();
            //}
        //}
    }

    void MemberFunc(int a) {
        //tBindFunc_mutex.lock();
        //bool locked = false;
        //while (!locked) {
            //if (tBindFunc_mutex.try_lock()) {
                //const std::lock_guard<std::mutex> lock3(tBindFunc_mutex);
        std::unique_lock<std::mutex> lock3(tBindFunc_mutex, std::defer_lock);

        if (lock3.try_lock()) { //doing the try_lock() call here
            std::cout << std::this_thread::get_id() << ", lock achieved!" << std::endl;
        }
        else {
            std::cout << std::this_thread::get_id() << ", failed getting lock." << std::endl;
        }

                Iprint("Bound Member Function", a);
                
                //locked = true;
                //tBindFunc_mutex.unlock();
            //}
       // }
    }
    

};

void ThreadTestFunc() {
    //tFreeFunc_mutex.lock();
    //bool locked = false;
    //while (!locked) {
      //  if (tFreeFunc_mutex.try_lock()) {
            const std::lock_guard<std::mutex> lock4(tFreeFunc_mutex);
            Iprint("Free function", 100);
            
            //locked = true;
            //tFreeFunc_mutex.unlock();
        //}
    //}
}

int main() {
    
    auto ec1 = std::make_error_condition(std::errc::operation_not_permitted); //this is for no associated mutex type error
    auto ec2 = std::make_error_condition(std::errc::resource_deadlock_would_occur); //this is for if a unique lock already has a mutex locked
    

    std::chrono::time_point
        <std::chrono::system_clock> startFull, endFull;
    startFull = std::chrono::system_clock::now();

    using namespace std::placeholders;
    auto storedLambda = [](int a) {
        //tStoredLambda_mutex.lock();
        //bool locked = false;
        //while (!locked) {
            //if (tStoredLambda_mutex.try_lock()) {
                const std::lock_guard<std::mutex> lock5(tStoredLambda_mutex);
                Iprint("Stored lambda: ", 20);
                
                //locked = true;
                //tStoredLambda_mutex.unlock();
            //}
        //}
    };

    try {
    //creating thread - free function 
    std::thread tFreeFunc(&ThreadTestFunc);
    //std::thread t1(transferThread, &ThreadTestFunc, &ThreadClassTest::StaticThreadFunc);

    //creating thread - static member function 
    std::thread tStaticMemberFunc(&ThreadClassTest::StaticThreadFunc, 20);
    //std::thread t2(&ThreadClassTest::StaticThreadFunc, 100);
    //tStaticMemberFunc.detach(); //lucky staticThreadFunc detachment

    //creating thread - binding a member function 
    ThreadClassTest cTest(5);
    auto boundFunc = std::bind(&ThreadClassTest::MemberFunc,&cTest, _1);
    std::thread tBindFunc(boundFunc,20);
    //std::thread::id ID = tBindFunc.get_id();

    //creating thread - callable function object
    CallableTestThread callObj(10);    
    std::thread tCallObj(callObj);


    //creating thread - stored lambda 
    std::thread tStoredLambda(storedLambda, 20);

    //creating thread - lambda
    std::thread tLambda([]() { 
        //tLambda_mutex.lock();
        //bool locked = false;
        //while (!locked) {
            //if (tLambda_mutex.try_lock()) {
                const std::lock_guard<std::mutex> lock6(tLambda_mutex);
                Iprint("Free Lambda", 20);
                std::cout << std::endl;
                
                //locked = true;
                //tLambda_mutex.unlock();
            //}
        //}
    }); 


   
    
        //commenting any of these joins will result in abort() error and crash the program.
        tFreeFunc.join();
        tStaticMemberFunc.join();
        tBindFunc.join();
        tCallObj.join();
        tStoredLambda.join();
        tLambda.join();

    }
    catch (const std::ios_base::failure& e) {
        
        std::error_code ec1(e.code());
        std::error_code ec2(e.code());
        //std::error_condition ec2(5, ec1.category());

            if (e.code() == std::io_errc::stream) {
                std::cout << "The error code and what: " << e.code() << ", " << e.what() << std::endl;

                std::cout << "ec1 value, message, and category name are: " << ec1.value() << ", " << ec1.message() << ", " << ec1.category().name() << std::endl;
                std::cout << "ec2 value, message, and category name are: " << ec2.value() << ", " << ec2.message() << ", " << ec2.category().name() << std::endl;
            }
    }

    catch (...) {
        std::cout << "catch all\n";
    }
    
    endFull = std::chrono::system_clock::now();

    std::chrono::duration<double>
        elapsed_secondsFull = endFull - startFull;
    std::time_t end_time =
        std::chrono::system_clock::to_time_t(endFull);

    std::cout << "Finished computation at "
        << "elapsed time: "
        << elapsed_secondsFull.count() << "s\n";
    std::cout << "\nTry Lock counter = " << tryLockCtr << std::endl;

    /*
   tFreeFunc.join();
   tStaticMemberFunc.join();
   tBindFunc.join();
   tCallObj.join();
   tStoredLambda.join();
   tLambda.join();
   */
    return 0;
}