#include <future>
#include <iostream>
#include <numeric>
#include <vector>
#include <chrono>
#include <thread>
#include <functional>

void Func(std::future<double>& fut) {
	std::cout << "fut value = " << fut.get() << std::endl;
}

void Func2(std::future<double>& fut) {
	double x = fut.get();
	std::cout << "value of fut: " << x << '\n';
}

int main() {
	std::promise<double> promise1;
	std::promise<double> promise2(std::move(promise1));
	std::promise<double> promise3;
	//promise3.set_value(3.14);
	std::future<double> fut1 = promise3.get_future();
	//std::cout << "fut1 result after function: " << fut1.get() << std::endl;

	std::thread t1(Func2, std::ref(fut1));  
	promise3.set_value(10);                         
													 
	t1.join();

	return 0;
}