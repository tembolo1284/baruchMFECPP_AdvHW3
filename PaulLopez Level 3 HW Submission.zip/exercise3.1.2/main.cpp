#include <iostream>
#include <thread>
#include <functional>
#include <mutex>

std::mutex tFreeFunc_mutex;
std::mutex tStaticMemberFunc_mutex;
std::mutex tBindFunc_mutex;
std::mutex tCallObj_mutex;
std::mutex tStoredLambda_mutex;
std::mutex tLambda_mutex;
int tryLockCtr{};

void Iprint(const std::string& s, int count) {
    
    for (int i = 0; i < count; i++) {
        std::cout << s << " ID: " << std::this_thread::get_id() << std::endl;
    }
}

class CallableTestThread {
public:
    int m_iterations;
    CallableTestThread(int iter) : m_iterations(iter) {}

    void operator() () {
        //tCallObj_mutex.lock();
        bool locked = false;
        while (!locked) {
            if (tCallObj_mutex.try_lock()) {
                Iprint("Callable function Object", 500);
                tryLockCtr++;
                locked = true;
                tCallObj_mutex.unlock();
            }
        }
    }

};
class ThreadClassTest {
public:
    int a;
    ThreadClassTest(int n) : a(n) {}

    static void StaticThreadFunc(int a) {
        //tStaticMemberFunc_mutex.lock();
        bool locked = false;
        while (!locked) {
            if (tStaticMemberFunc_mutex.try_lock()) {
                Iprint("Static Member Function", a);
                tryLockCtr++;
                locked = true;
                tStaticMemberFunc_mutex.unlock();
            }
        }
    }

    void MemberFunc(int a) {
        //tBindFunc_mutex.lock();
        bool locked = false;
        while (!locked) {
            if (tBindFunc_mutex.try_lock()) {
                Iprint("Bound Member Function", a);
                tryLockCtr++;
                locked = true;
                tBindFunc_mutex.unlock();
            }
        }
    }
    

};

void ThreadTestFunc() {
    //tFreeFunc_mutex.lock();
    bool locked = false;
    while (!locked) {
        if (tFreeFunc_mutex.try_lock()) {
            Iprint("Free function", 500);
            tryLockCtr++;
            locked = true;
            tFreeFunc_mutex.unlock();
        }
    }
}

int main() {
    //for keeping the time in part f) I could have timed each thread individually or 
    //keep time for the entire main.  I kept a separate piece to time the stored lambda function at the bottom.
    std::chrono::time_point
        <std::chrono::system_clock> startFull, endFull;
    startFull = std::chrono::system_clock::now();

    using namespace std::placeholders;
    auto storedLambda = [](int a) {
        //tStoredLambda_mutex.lock();
        bool locked = false;
        while (!locked) {
            if (tStoredLambda_mutex.try_lock()) {
                Iprint("Stored lambda: ", 5000);
                tryLockCtr++;
                locked = true;
                tStoredLambda_mutex.unlock();
            }
        }
    };
    //creating thread - free function 
    std::thread tFreeFunc(&ThreadTestFunc);

    //creating thread - static member function 
    std::thread tStaticMemberFunc(&ThreadClassTest::StaticThreadFunc, 5000);
    tStaticMemberFunc.detach(); //lucky staticThreadFunc detachment

    //creating thread - binding a member function 
    ThreadClassTest cTest(5);
    auto boundFunc = std::bind(&ThreadClassTest::MemberFunc,&cTest, _1);
    std::thread tBindFunc(boundFunc,5000);
    std::thread::id ID = tBindFunc.get_id();

    //creating thread - callable function object
    CallableTestThread callObj(50);    
    std::thread tCallObj(callObj);


    //creating thread - stored lambda 
    std::thread tStoredLambda(storedLambda, 5000);

    //creating thread - lambda
    std::thread tLambda([]() { 
        //tLambda_mutex.lock();
        bool locked = false;
        while (!locked) {
            if (tLambda_mutex.try_lock()) {
                Iprint("Free Lambda", 50000);
                std::cout << std::endl;
                tryLockCtr++;
                locked = true;
                tLambda_mutex.unlock();
            }
        }
    }); 


    /*
    tFreeFunc.join();
    tStaticMemberFunc.join();
    tBindFunc.join();
    tCallObj.join();
    tStoredLambda.join();
    tLambda.join();
    */
    try {

        if (tFreeFunc.joinable()) {
            //throw 1;
            tFreeFunc.join();
        }
        else {
            throw 1;
        }
        if (tStaticMemberFunc.joinable()) {
            //throw 2; 
            tStaticMemberFunc.join();
        }
        else {
            //throw 2;
        }
        if (tBindFunc.joinable()) {
            //throw 3;
            tBindFunc.join();
        }
        else {
            throw 3;
        }
        if (tCallObj.joinable()) {
            //throw 4; 
            tCallObj.join();
        }
        else {
            throw 4;
        }
        if (tStoredLambda.joinable()) {
            //throw 5; 
            tStoredLambda.join();
        }
        else {
            throw 5;
        }
        if (tLambda.joinable()) {
            //throw 6; 
            tLambda.join();
        }
        else {
            throw 6;
        }
    }
    catch (int err) {
        switch (err) {
        case 1: {
            std::cout << "tFreeFunc join attempt" << std::endl;
            tFreeFunc.join();
            break;
        }
        case 2: {
            std::cout << "tStaticMemberFunc join attempt" << std::endl;
            tStaticMemberFunc.join();
            break;
        }
        case 3: {
            std::cout << "tBindFunc join attempt" << std::endl;
            tBindFunc.join();
            break;
        }
        case 4: {
            std::cout << "tCallObj join attempt" << std::endl;
            tCallObj.join();
            break;
        }
        case 5: {
            std::cout << "tStoredLambda join attempt" << std::endl;
            tStoredLambda.join();
            break;
        }
        case 6: {
            std::cout << "tLambda join attempt" << std::endl;
            tLambda.join();
            break;
        }

        }

    }
    
    endFull = std::chrono::system_clock::now();

    std::chrono::duration<double>
        elapsed_secondsFull = endFull - startFull;
    std::time_t end_time =
        std::chrono::system_clock::to_time_t(endFull);

    std::cout << "Finished computation at "
        << "elapsed time: "
        << elapsed_secondsFull.count() << "s\n";
    std::cout << "\nTry Lock counter = " << tryLockCtr << std::endl;

    //a )Finished computation at elapsed time : 0.362995s
    //this was the time end to end placing lock and unlock before and after every call to Iprint().
    //b) Barely slowed it down if at all. I can't really get the count above 6 unless I make the integer calls > 10k.
    // and the count is maybe 7-8 but never > 10. Each lock attempt is basically succeeding.
    //c)I always get an abort debug error and the program crashes when I comment out the unlock() lines. No good!
    return 0;
}