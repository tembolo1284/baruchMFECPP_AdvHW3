#include <iostream>
#include <memory>

struct X {
    double val;

    X() : val(0.0) {}
    void operator ()() {
        std::cout << "An X " << val << std::endl;
    }
};

template <typename T>
using GenericPointerType = std::shared_ptr<T>;
using PointerType = GenericPointerType<X>;

int main() {

    PointerType x1 = std::make_shared<X>();
    x1->val = 5.0;
    std::cout << "x1 use_count: " << x1.use_count() << std::endl;

    std::cout << "\nx1 value = " << x1->val << std::endl;  //5.0
    PointerType x2 = std::make_shared<X>();
    x2->val = 71.5;
    std::cout << "\nx2 use_count: " << x2.use_count() << std::endl;
    std::cout << "\nx2 value = " << x2->val << std::endl;
    std::atomic_store(&x1, x2); //couldn't do this in c++ 20 made me sad. Went to c++ 17

    std::cout << "x1 use_count: " << x1.use_count() << std::endl;
    std::cout << "x2 use_count: " << x2.use_count() << std::endl;
    std::cout << "\nx1 value = " << x1->val << std::endl; // 71.5

    PointerType x3 = std::make_shared<X>();
    x3->val = 22.22;
    std::cout << "\nx3 use_count: " << x3.use_count() << std::endl;
    //swap x3 with x1.
    x3.swap(x1);
    std::cout << "\nx1 use_count: " << x1.use_count() << std::endl;
    std::cout << "x3 use_count: " << x3.use_count() << std::endl;

    std::cout << "\nx1 value = " << x1->val << std::endl; //22.22
    std::cout << "\nx3 value = " << x3->val << std::endl; //71.5
    x3->val = 88.88;

    x3.swap(x2);

    std::cout << "\nx1 use_count: " << x1.use_count() << std::endl;
    std::cout << "x2 use_count: " << x2.use_count() << std::endl;
    std::cout << "x3 use_count: " << x3.use_count() << std::endl;

    std::cout << "\nx2 value = " << x2->val << std::endl; //88.88
    std::cout << "x3 value = " << x3->val << std::endl; //88.88 x3 stayed as 88.88!

    //when I try to do atomic <std::shared_ptr> I get that shared_ptrs are not trivially copyable, and that is
    // something that atomic objects require.
    
    //std::cout << "Is x1 lock free? " << x1.is_lock_free() << std::endl; //can't do this.
    //I'd say shared ptr operations that don't result in an increase in use count would be lock free.

}